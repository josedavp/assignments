
#include <stdio.h>

int power( int base, int n )
{
    /*
    5^3 = 5 * 5 * 5
    5^3 = 5 * 5^2
    5^2 = 5 * 5^1
    5^1 = 5 * 5^0
    5^0 = 1

    power ( base, n) = base * power (base, n -1)
    */
    if ( n == 0)
    {
        return 1;
    }
    if ( n == 1) 
    {
        return base;
    }

   // base * power(base, n-1);
    return base * power(base, n-1);

}
int sumDigits(int num)
{
    /*
        sumDigits ( 1713 ) = sumDigits (171) + 3
        sumDigits ( 171 ) = sumDigits (17) + 1
        sumDigits ( 17 ) = sumDigits (1) + 7
        sumDigits ( 1 ) =  1

        sumDigits ( num ) = sumDigits ( num / 10 ) + num % 10;
    */
     if ( num < 10)
     {
         return num;
     }

     return sumDigits(num/10) + num  % 10;

}
int main (int argc, char *argv) 
{
    int x = power( 5, 3);
    printf( "%d\n", x);

    int y = sumDigits( 9876 );
    printf("%d\n", y);

    return 0;
}

