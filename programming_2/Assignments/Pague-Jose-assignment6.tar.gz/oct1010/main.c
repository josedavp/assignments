#include <stdio.h> 

int main ( int argc, char *argv[] ) 
{
    FILE *fileIn = NULL;
    FILE *fileOut = NULL;
    char buffer[2000];
    int count = 0;

    fileIn = fopen( "mydata.csv", "r");
    fileOut = fopen( "newdata.txt", "w");

    /* this code checks to see if the file opened */
    if ( fileIn == NULL) 
    {
        printf( "ERROR file does not exist.\n" );
        return 1;
    }
    /*this code reads in one line at a time */
    while( fgets(buffer, 2000, fileIn ) != NULL )
    {
        if ( count > 0)
        {
            
        int districtNumber;
        char district[ 100 ];
        char school[ 100 ];
        int num1, num2, num3, num4, num5, num6, num7,num8,num9;

        sscanf (buffer, "%d,%[^,],%[^,],%d,%d,%d,%d,%d,%d,%d,%d,%d", &districtNumber, district, school, &num1, &num2, &num3, &num4, &num5, &num6, &num7, &num8, &num9);
            if ( num3 > 0 )
            {
                fprintf( fileOut, "School #%d: %d, %s, %s\n", count, districtNumber, district, school);
            }
        }
        count++;
                         // fprintf( fileOut, "%s\n", buffer );
                        // fprintf( fileOut, "hello"); // to change whats inside file
    }


    fclose (fileIn);
    fclose (fileOut);

    return 0;
}
