#include <stdio.h>

int main ( int argc, char * argv) 
{
    int x =[] = { 50, 30, 70, 80, 20, 60, 100, 90};
    int i;

    mergeSortRecords(x, 0, 7);
    /* for project 2, it'll be:

       assume that there is a variable called length that 
     */

    for (i = 0; i < 8; i++) 
    {

    }








}

void mergeSortRecords( int number[], int min, int max )
{
    int mid;

    if (min < max)
    {
        mid = (min + max) / 2;

        mergeSortRecords(data, min, mid);
        mergeSortRecords(data, mid + 1, max);

        mergeRecords(data, min, mid, max); // problem
    }
}

/* for project 2,
   void mergeRecord( CourseRecord *data, int i, int j, int k)
 */

void mergeRecords( int numbers[], int min, int mid, int max)
{
    //use string compare for each array element
    int mergedSize = max - min + 1;
    CourseRecord *mergedNum[mergedSize];
    int mergedPos;
    int leftPos;
    int rightPos;

    mergedPos = 0;
    leftPos = min;
    rightPos = mid + 1;

    while ( leftPos <= mid && rightPos <= max) 
    {
        if( data[leftPos].crn < data[rightPos].crn) 
        {        
            strcpy(mergedNum[mergedPos].subject, data[leftPos].subject);  
            mergedNum[mergedPos].course = data[leftPos].course;
            strcpy(mergedNum[mergedPos].section, data[leftPos].section);
            mergedNum[mergedPos].crn = data[leftPos].crn;
            strcpy(mergedNum[mergedPos].title, data[leftPos].title);
            strcpy(mergedNum[mergedPos].days, data[leftPos].days);
            strcpy(mergedNum[mergedPos].times, data[leftPos].times);
            strcpy(mergedNum[mergedPos].instructor, data[leftPos].instructor);
            mergedNum[mergedPos].enrolled = data[leftPos].enrolled;
            ++leftPos;
        }
        else // data[rightPos]
        {
            strcpy(mergedNum[mergedPos].subject, data[rightPos].subject);  
            mergedNum[mergedPos].course = data[rightPos].course;
            strcpy(mergedNum[mergedPos].section, data[rightPos].section);
            mergedNum[mergedPos].crn = data[rightPos].crn;
            strcpy(mergedNum[mergedPos].title, data[rightPos].title);
            strcpy(mergedNum[mergedPos].days, data[rightPos].days);
            strcpy(mergedNum[mergedPos].times, data[rightPos].times);
            strcpy(mergedNum[mergedPos].instructor, data[rightPos].instructor);
            mergedNum[mergedPos].enrolled = data[rightPos].enrolled;
            ++rightPos;
        }
        ++mergedPos;
    }

    while ( leftPos <= mid )
    {
        strcpy(mergedNum[mergedPos].subject, data[leftPos].subject);  
        mergedNum[mergedPos].course = data[leftPos].course;
        strcpy(mergedNum[mergedPos].section, data[leftPos].section);
        mergedNum[mergedPos].crn = data[leftPos].crn;
        strcpy(mergedNum[mergedPos].title, data[leftPos].title);
        strcpy(mergedNum[mergedPos].days, data[leftPos].days);
        strcpy(mergedNum[mergedPos].times, data[leftPos].times);
        strcpy(mergedNum[mergedPos].instructor, data[leftPos].instructor);
        mergedNum[mergedPos].enrolled = data[leftPos].enrolled;
        ++leftPos;
        ++mergedPos;
    }

    while( rightPos <= max)
    {
        strcpy(mergedNum[mergedPos].subject, data[rightPos].subject);  
        mergedNum[mergedPos].course = data[rightPos].course;
        strcpy(mergedNum[mergedPos].section, data[rightPos].section);
        mergedNum[mergedPos].crn = data[rightPos].crn;
        strcpy(mergedNum[mergedPos].title, data[rightPos].title);
        strcpy(mergedNum[mergedPos].days, data[rightPos].days);
        strcpy(mergedNum[mergedPos].times, data[rightPos].times);
        strcpy(mergedNum[mergedPos].instructor, data[rightPos].instructor);
        mergedNum[mergedPos].enrolled = data[rightPos].enrolled;
        ++rightPos;
        ++mergedPos;
    }
    for ( mergedPos = 0; mergedPos < mergedSize; ++mergedPos)
    {
        data[ min + mergedPos].crn = mergedNum[mergedPos];
    }
}

