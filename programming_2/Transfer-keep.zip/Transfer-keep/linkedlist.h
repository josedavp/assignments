#ifndef LINKEDLIST_H 
#define LINKEDLIST_H

typedef struct LLNode 
{
    int value;              /* the value of this node */
    struct LLNode *next;    /* pointer to the next node */
} LLNode;

/* prototypes */
LLNode *insertNode( LLNode *, int );
LLNode *find( LLNode *, int );
LLNode *removeNode( LLNode *h, int k );
void print( LLNode * );
LLNode *destruct( LLNode * );

#endif
