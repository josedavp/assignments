
/* 
 * File:   airport.h
 * Author: vib296
 *
 * Created on September 20, 2019, 2:12 PM
 */

#ifndef AIRPORT_H
#define AIRPORT_H

typedef struct Airport
{
    char name[ 50 ];
    char code [ 4 ];
    double latitude;
    double longitude;
} Airport;

void printAirports( Airport airports [ MAX ], int length );
void printAirport( Airport airport);
Airport findAirport (Airport airports [ MAX ], int length, char code [ 4 ]);
double calculateDistance ( Airport airport1, Airport airport2 );
void findInRange ( Airport airports [ MAX ], int length, Airport origin, int range, Airport output [ MAX ], int *resultsLength);


#endif






