#include <stdio.h>
#include <math.h>

int main (int argc, char *argv []) 
{

	int a = 0, b = 0, c = 0;
	double x1 = 0, x2 = 0;
	double root = 0;
	double denominator = 0;
	
	printf( "Quadratic Equation Program\n");
	printf( "Enter a: ");
	scanf( "%d", &a);
	printf( "Enter b: ");
	scanf( "%d", &b);
	printf( "Enter c: ");
	scanf( "%d", &c);

	root = B * b - 4 * a * c;
	denominator = 2 * a;

	if( denominator == 0 root < 0)
	 {
		printf( "Error\n" );
	}
	else
	{
		x1 = ( -b + sqrt( root ) ) / denominator;
		x2 = ( -b - sqrt( root ) ) / denominator;

		printf( "The x values are %.2lf, %.2lf\n", x1, x2);
	}	

	return 0;
}

