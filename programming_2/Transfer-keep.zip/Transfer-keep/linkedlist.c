#include <stdio.h>
#include <stdlib.h>
#include "linkedlist.h"

/*
    Function: insertNode
    -------------------
    This function creates a new node with the value from the parameter
    and adds it to the linked list from the front. It returns the head
    of the new linked.
    Insertion is done PREPENDING.
        h: the head of the linked list
        x: the value that will be stored in the linked list
    Returns: New head of the linked list 
*/
LLNode *insertNode( LLNode *h, int x )
{
    /* dynamically create a new LLNode */
    LLNode *n = (LLNode *) malloc( sizeof( LLNode ) );
    n->value = x;   /* value assignment */
    n->next = h;    /* since this new node will be preppended, it's next
                       pointer will point to the rest of the list */
    return n;
}

/* 
    Function: find 
    -------------------
    This function finds a linked list node whose value matches the key
    and returns a pointer to that node. This function will only find the
    FIRST occurence of the key value. It will return NULL if it was not
    found.
        h: the head of the linked list
        k: the key value you are trying to find
    Returns: a pointer to the node with the key or NULL 
*/
LLNode *find( LLNode *h, int k )
{
    LLNode *ptr;
    /* go through each node and check to the value against the key */
    for( ptr = h; ptr != NULL; ptr = ptr->next )
    {
        if( ptr->value == k )
        {
            return ptr;
        }
    }
    /* if we reach this part, that means the value was not found */
    return ptr;
}

/* 
    Function: removeNode
    -------------------
    This function removes a linked list node whose value matches the key
    and returns the head of the linked list. This function will only 
    remove the FIRST occurrence of the key value.
        h: the head of the linked list
        k: the key value you are trying to find
    Returns: the head of the linked list 
*/
LLNode *removeNode( LLNode *h, int k )
{
    LLNode *ptr;
    LLNode *prev;   /* a previous pointer is needed when a node is
                       removed from the linked list. */
    for( ptr = h; ptr != NULL; ptr = ptr->next )
    {
        if( ptr->value == k )
        {
            LLNode *temp = ptr; /* create a temporary pointer to the node*/

            /* first check to see if the key is in the head */
            if( ptr == h )      
            {
                h = h->next; /* advance the pointer to the next node */     
            }
            else
            {
                /* connect the previous's node's next pointer to the 
                   current node's next pointer */
                prev->next = ptr->next; 
            }
            free( temp );   /* deallocate */
            return h;       /* return new head and leave */
        }
        /* if not found in this iteration, set prev pointer to the next 
           pointer in preparation for the next iteration */
        prev = ptr;
    }
    return h;
}

/*
    Function: print 
    -------------------
    This function traverses the linked list and prints out each node's
    value.
        h: the head of the linked list
    Returns: Nothing
*/
void print( LLNode *h )
{
    LLNode *ptr;
    /* this for loop goes through each node from head until the end,
       and prints out each value */
    for( ptr = h; ptr != NULL; ptr = ptr->next )
    {
        printf( "Value: %d\n", ptr->value );
    }
}

/*
    Function: destruct 
    -------------------
    This function goes through each item in the linked list and 
    free it. It should only be called at the end of a program when
    the linked list is no longer needed.
        h: the head of the linked list
    Returns: NULL  
*/
LLNode *destruct( LLNode *h )
{
    /* go through each item in the linked list, for each node and
       free it */
    while( h != NULL )
    {
        LLNode *temp = h;   /* set temporary pointer */
        h = h->next;        /* advance the ptr to the next item */
        free( temp );       /* free the next pointer */
    }
    return NULL;
}

